package model;

import java.util.ArrayList;

public class UserDatabase {
    private static ArrayList<User> users;
    public static User getUserByUsername (String username) {
        return null;
    }

}

