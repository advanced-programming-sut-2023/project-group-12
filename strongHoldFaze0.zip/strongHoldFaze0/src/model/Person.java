package model;

public class Person {
    private boolean isReligious;
}
