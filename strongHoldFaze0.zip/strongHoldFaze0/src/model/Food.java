package model;

public class Food {
    private String name;
    private int amount;
    // TODO: enum for food names, food price
}
