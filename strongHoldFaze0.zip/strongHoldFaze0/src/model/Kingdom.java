package model;

public class Kingdom {
    private int popularity;
    // TODO: food rate enum, tax rate enum, fear rate enum
    private int foodPortion;
}
