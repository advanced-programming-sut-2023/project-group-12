package model;

public class Cell {
    private int x;
    private int y;
    // building, material, population, ...
    // TODO: show info

}
