package controller;

public class LoginController {
    private static int incorrectPassword;
    public String login () {
        return "";
    }
    // TODO : a method to delay logging in by that time
}
