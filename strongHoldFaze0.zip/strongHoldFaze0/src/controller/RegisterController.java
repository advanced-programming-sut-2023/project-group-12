package controller;

import java.util.regex.Matcher;

public class RegisterController {
    public String register (Matcher matcher) {
        return "";
    }
    private boolean isCorrectPassword (String password) {
        return false;
    }
    private boolean isCorrectUsername (String username) {
        return false;
    }
}
