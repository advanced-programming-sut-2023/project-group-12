public class Main {
    public static void main(String[] args) {
        String hello = "Hello world!";
        System.out.println(hello.toUpperCase());
    }
}