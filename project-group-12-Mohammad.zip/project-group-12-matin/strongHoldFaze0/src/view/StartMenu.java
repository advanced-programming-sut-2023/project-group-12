package view;

import model.User;

import java.awt.*;
import java.util.ArrayList;
import java.util.regex.Matcher;

public class StartMenu {
    // starting game
    // creating game field ( menu )
    // choosing map
    public void run () {

    }

    private void chooseKeep(Matcher matcher) {

    }
    private void removeMap(Matcher matcher) {

    }
    private void chooseMap(Matcher matcher) {

    }
    private void userCount(Matcher matcher) {

    }
}
