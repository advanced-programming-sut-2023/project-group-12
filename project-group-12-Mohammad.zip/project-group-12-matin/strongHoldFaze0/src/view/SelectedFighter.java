package view;

import java.util.regex.Matcher;

public class SelectedFighter {
    public void run() {

    }

    private void moveUnit(Matcher matcher) {

    }

    private void patrolUnit(Matcher matcher) {

    }
}
