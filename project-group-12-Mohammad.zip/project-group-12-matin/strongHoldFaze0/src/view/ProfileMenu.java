package view;

import java.util.regex.Matcher;

public class ProfileMenu {
    public void run () {

    }
    private void changeUsername(Matcher matcher) {

    }
    private void ChangeNickname(Matcher matcher) {

    }

    private void changePassword(Matcher matcher) {

    }

    private void changeEmail(Matcher matcher) {

    }

    private void changeSlogan(Matcher matcher) {

    }

    private void displayHighScore(Matcher matcher) {

    }

    private void displayRank(Matcher matcher) {

    }

    private void displaySlogan(Matcher matcher) {

    }

    private void displayAll(Matcher matcher) {

    }
}
