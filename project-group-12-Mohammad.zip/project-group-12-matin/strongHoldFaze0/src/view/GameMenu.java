package view;


import java.util.regex.Matcher;

public class GameMenu {

    public void run () {

    }

    private void dropBuilding(Matcher matcher) {

    }

    private void selectBuilding(Matcher matcher) {

    }

    private void selectUnit(Matcher matcher) {

    }
    private void nextTurn() {

    }
}
