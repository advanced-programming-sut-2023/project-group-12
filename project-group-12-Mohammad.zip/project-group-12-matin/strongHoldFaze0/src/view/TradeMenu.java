package view;

import java.util.regex.Matcher;

public class TradeMenu {
    public void run () {

    }

    private void trading(Matcher matcher) {

    }

    private void showTradeList() {

    }

    private void tradeAccept(Matcher matcher) {

    }

    private void showTradeHistory() {

    }
}
