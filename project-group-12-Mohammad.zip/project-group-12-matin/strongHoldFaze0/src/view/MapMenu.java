package view;


import java.util.Map;
import java.util.regex.Matcher;

public class MapMenu {
    public void run () {

    }

    private void showMap(Matcher matcher) {

    }
    private void showDetail(Matcher matcher) {

    }

    private void setTexture(Matcher matcher) {

    }

    private void clear(Matcher matcher) {

    }

    private void dropRock(Matcher matcher) {

    }

    private void dropTree(Matcher matcher) {

    }

    private void dropBuilding(Matcher matcher) {

    }

    private void dropUnit(Matcher matcher) {

    }

    private void createNewMap() {

    }
}
