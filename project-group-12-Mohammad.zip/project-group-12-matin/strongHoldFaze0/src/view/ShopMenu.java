package view;

import java.util.regex.Matcher;

public class ShopMenu {

    public void run() {

    }

    private void showPriceList() {

    }

    private void buy(Matcher matcher) {

    }

    private void sell(Matcher matcher) {

    }
}
