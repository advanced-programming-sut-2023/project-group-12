package view;

import java.util.regex.Matcher;

public class MainMenu {
    public void run () {

    }

    private void enterToMapMenu(Matcher matcher) {

    }
    private void enterToProfileMenu(Matcher matcher) {

    }

    private void startGame(Matcher matcher) {

    }
}
