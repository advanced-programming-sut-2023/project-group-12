package view;

import java.util.Scanner;
import java.util.regex.Matcher;

public class SignupLoginMenu {
    public void run() {

    }

    private void register(Matcher matcher) {

    }

    private void login(Matcher matcher) {

    }

    private void forgotPassword(Matcher matcher) {

    }
}
