package view;

import java.util.Scanner;

public interface ScannerObject {
    Scanner scanner = new Scanner(System.in);
}
