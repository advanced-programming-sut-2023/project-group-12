package model;

public class Food extends Resources{
    private String name;
    private int amount;
    // TODO: enum for food names, food price
}

