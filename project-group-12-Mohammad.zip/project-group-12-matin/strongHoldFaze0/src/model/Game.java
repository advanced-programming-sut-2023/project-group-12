package model;

import java.util.ArrayList;

public class Game {
    private Map currentMap;
    private ArrayList<User> players;
    private User currentUser;
    private int roundsPassed;

    public void dropBuilding(int x, int y, String type) {

    }

    public void selectBuilding(int x, int y) {

    }

    public void selectUnit(int x, int y) {

    }
    public void nextTurn() {

    }
}
