package model.people.fighter.ballista;

import model.people.fighter.Fighter;
import model.people.fighter.Type;

public class PortableEnclosure extends Fighter {
    public PortableEnclosure(int xCoordinate, int yCoordinate, Type type) {
        super(xCoordinate, yCoordinate, type);
    }
    public void protectFighter () {

    }
}
