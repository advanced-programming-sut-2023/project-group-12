package model.people.fighter.soldier.specialsoldiers;

import model.people.fighter.Type;
import model.people.fighter.soldier.Soldier;

public class Ladderman extends Soldier {
    //laddermen
    public Ladderman(int xCoordinate, int yCoordinate, Type type) {
        super(xCoordinate, yCoordinate, type);
    }

    public void placeTheLadder(int xCoordinate, int yCoordinate) {

    }
}
