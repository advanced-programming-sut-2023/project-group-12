package model.people.fighter.soldier.warrior;

import model.people.fighter.Type;

public class Cavalry extends Warrior{
    public Cavalry(int xCoordinate, int yCoordinate, Type type) {
        super(xCoordinate, yCoordinate, type);
    }

    @Override
    public void move(int xCoordinate, int yCoordinate) {

    }
}
