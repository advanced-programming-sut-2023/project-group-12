package model.people.fighter;

public interface Movable {
    static void moving(Fighter fighter, int newXCoordinate, int newYCoordinate) {

    }
}
