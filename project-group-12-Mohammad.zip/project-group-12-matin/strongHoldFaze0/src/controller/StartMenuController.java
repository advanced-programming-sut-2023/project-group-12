package controller;

import model.User;

public class StartMenuController {
    private int userCount;

    public void setUserCount(int userCount) {
        this.userCount = userCount;
    }

    public void chooseMap (int mapNumber) {

    }
    public void removeMap (int mapNumber) {

    }
    public void chooseKeep (User user, int keepNumber) {
        // giving each
    }
}
