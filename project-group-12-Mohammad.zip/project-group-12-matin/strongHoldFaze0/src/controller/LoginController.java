package controller;

import java.util.regex.Matcher;

public class LoginController {
    public String login (String username, String password) {
        return "";
    }

    public String changePassword(String password){
        return null;
    }
    public String forgotPassword (String username, String answer, String newPassword) {
     return null;
    }
}
