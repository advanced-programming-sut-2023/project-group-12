package controller;

import model.User;

public class ProfileController {

    private User currentUser;

    public String changeUsername(String username){
        return null;
    }

    public String changeNickname(String nickname){
        return null;
    }

    public String changePassword(String password){
        return null;
    }

    public String changeEmail(String email){
        return null;
    }

    public String changeSlogan(String slogan){
        return null;
    }

    //remove slogan -> change slogan to null

    public int displayHighScore(){
        return 0;
    }

    public String displaySlogan(){
        return null;
    }

    public String displayAll(){
        return null;
    }


}
