package controller;

public class ShopController {

    public void showPriceList() {

    }

    public String buy(String itemName, int amount) {
        return "";
    }

    public String sell(String itemName, int amount) {
        return "";
    }
}
