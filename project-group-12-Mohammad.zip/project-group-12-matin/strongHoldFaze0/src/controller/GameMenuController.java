package controller;

import model.Building.Building;
import model.User;
import model.people.Unit;

public class GameMenuController {
    private User currentUser;
    private Unit selectedUnit;
    private Building selectedBuilding;
    public String dropBuilding(int x, int y, String type) {
        return "";
    }

    public void selectBuilding(int x, int y) {

    }

    public void selectUnit(int x, int y) {

    }
    public String nextTurn() {
        return "";
    }

    public void dropUnit(int x, int y, String type, int count) {

    }
    public String moveUnit(int x, int y) {
        return "";
    }

    public String patrolUnit(int originX, int originY, int destinationX, int destinationY) {
        return "";
    }
    public String createUnit(String type, int count) {
        return "";
    }

    public String repair() {
        return "";
    }
}
