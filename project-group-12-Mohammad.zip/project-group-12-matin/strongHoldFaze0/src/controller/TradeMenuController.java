package controller;

import model.Trade;
import model.User;

public class TradeMenuController {
    private static User currentUser;

    public static String sendTrade(String resourceType, int resourceAmount, int price, String message){
        return null;
    }

    public static void showAllCurrentTrades(){

    }

    public static void acceptTrade(int id, String messages){

    }

    public static Trade getTradeById(int id){
        return null;
    }

    public static void showAllTrades(){

    }

}
