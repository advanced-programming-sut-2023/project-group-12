package model;

import java.util.ArrayList;
import java.util.HashMap;

public class UserDatabase {
    private static User currentUser;

    private static ArrayList<User> users;
    private static ArrayList<User> players;// should be cleared after each game

    public static User getUserByUsername (String username) {
        for (User user: users){
            if(user.getUsername().equals(username)){
                return user;
            }
        }
        return null;
    }

    public static boolean isEmailExists (String email) {
        for (User user: users){
            if(user.getUsername().equals(email)){
                return true;
            }
        }
        return false;
    }

    public static void addUser(User userRegister) {
        users.add(userRegister);
    }
}

