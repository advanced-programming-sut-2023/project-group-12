package view;

import controller.GameMenuController;

import java.util.Scanner;
import java.util.regex.Matcher;

public class GameMenu {
    public void run (Scanner scanner) {
        String input;
        GameMenuController controller = new GameMenuController();

    }
}
