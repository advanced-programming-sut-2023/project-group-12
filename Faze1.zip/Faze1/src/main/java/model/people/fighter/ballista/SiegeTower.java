package model.people.fighter.ballista;

import model.people.fighter.Fighter;
import model.people.fighter.Type;

public class SiegeTower extends Fighter {
    public SiegeTower(int xCoordinate, int yCoordinate, Type type) {
        super(xCoordinate, yCoordinate, type);
    }
    public void moveToTop (int x, int y, Fighter fighter) {

    }
}
