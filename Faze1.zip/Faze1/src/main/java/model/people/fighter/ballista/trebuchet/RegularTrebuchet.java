package model.people.fighter.ballista.trebuchet;

import model.people.fighter.Type;

public class RegularTrebuchet extends Trebuchet{
    public RegularTrebuchet(int xCoordinate, int yCoordinate, Type type) {
        super(xCoordinate, yCoordinate, type);
    }
}
