package model.people.fighter.soldier;

public enum Situation {
    STANDING,
    DEFENSIVE,
    OFFENSIVE;
}
