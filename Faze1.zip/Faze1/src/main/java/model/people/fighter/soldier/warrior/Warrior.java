package model.people.fighter.soldier.warrior;

import model.people.fighter.soldier.Soldier;
import model.people.fighter.Type;

public class Warrior extends Soldier {

    public Warrior(int xCoordinate, int yCoordinate, Type type) {
        super(xCoordinate, yCoordinate, type);
    }

    public void attackToEnemy(int xCoordinate, int yCoordinate) {

    }
}
