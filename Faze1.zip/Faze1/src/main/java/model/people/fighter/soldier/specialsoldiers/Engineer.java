package model.people.fighter.soldier.specialsoldiers;

import model.people.fighter.Type;
import model.people.fighter.soldier.Soldier;

public class Engineer extends Soldier {
    public Engineer(int xCoordinate, int yCoordinate, Type type) {
        super(xCoordinate, yCoordinate, type);
    }

    public void pourOil(String direction) {

    }
    public void buildSiegeTent () {

    }
}
