package model.people.fighter.soldier.specialsoldiers;

import model.people.fighter.Type;
import model.people.fighter.soldier.Soldier;

public class Tunneler extends Soldier {
    public Tunneler(int xCoordinate, int yCoordinate, Type type) {
        super(xCoordinate, yCoordinate, type);
    }

    public void digTunnel(int xCoordinate, int yCoordinate) {

    }
}
