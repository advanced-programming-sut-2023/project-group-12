package model.people.fighter.ballista;

import model.people.fighter.Fighter;
import model.people.fighter.Type;

public class BatteringRam extends Fighter {
    public BatteringRam(int xCoordinate, int yCoordinate, Type type) {
        super(xCoordinate, yCoordinate, type);
    }

    public void breakGate(int xCoordinate, int yCoordinate) {

    }
}
