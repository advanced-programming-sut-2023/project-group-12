package model.people.fighter.ballista.trebuchet;

import model.people.fighter.Type;

public class CounterweightTrebuchet extends Trebuchet{
    public CounterweightTrebuchet(int xCoordinate, int yCoordinate, Type type) {
        super(xCoordinate, yCoordinate, type);
    }
}
