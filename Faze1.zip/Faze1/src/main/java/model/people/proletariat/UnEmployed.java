package model.people.proletariat;

import model.Kingdom;
import model.people.Unit;

public class UnEmployed extends Unit {

    public UnEmployed(Kingdom homeland, int life) {
        super(homeland, life);
    }
}
