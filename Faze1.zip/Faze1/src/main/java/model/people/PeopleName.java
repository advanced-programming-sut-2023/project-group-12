package model.people;

public enum PeopleName {
}
