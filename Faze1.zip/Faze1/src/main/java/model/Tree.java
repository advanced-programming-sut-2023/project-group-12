package org.example;

public enum Tree {
    DESERT_SHRUB,
    CHERRY,
    OLIVE,
    COCONUT,
    DATE;
}
