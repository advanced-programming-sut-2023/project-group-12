package org.example;

public class Map {
    private Cell[][] map;

    public Map(int dimension) {
        map = new Cell[dimension][dimension];
    }

    public Cell[][] getMap() {
        return map;
    }
}