package model;

import java.util.HashMap;

public class Resources {
    private HashMap <ResourceType, Integer> amounts;
}
