package controller;

public class MapMenuController {
    public String  setCellTexture (int x, int y, String type) {
        return "";
    }
    public String setCellsTexture (int x1, int y1, int x2, int y2, String type) {
        return "";
    }
    public String clear (int x, int y) {
        return "";
    }
    public String dropRock (int x, int y, char direction) {
        return "";
    }
    public String dropTree (int x, int y, String type) {
        return "";
    }
}
