package controller;

public class GameMenuController {
    public String chooseColor(String color) {
        return "";
    }
    public String changeColor (String color) {
        return "";
    }
    public String chooseKeep (int keepNumber) {
        return "";
    }
    public String changeKeep (int keepNumber) {
        return "";
    }
    public String dropBuilding (int x, int y, String type) {
        return "";
    }
    public String dropUnit (int x, int y, String type, int count) {
        return "";
    }
}
