package controller;

public class TradeMenuController {
    public String showAllTrades () {
        return "";
    }
    public String trade (String resourceType, int resourceAmount,int price, String message) {
        return "";
    }
    public String acceptTrade (String tradeId, String message) {
        return "";
    }
    public String showTradeHistory () {
        return "";
    }
}
