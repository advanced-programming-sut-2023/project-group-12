package controller;

public class ShopMenuController {
    public String buyOrSell (String action, String name, int amount) {
        if (action.equals("buy")) {
            // we buy that thing
        }
        else if (action.equals("sell")) {
            // we sell that thing
        }
        return "";
    }
    public String showPriceList() {
        return "";
    }
}
